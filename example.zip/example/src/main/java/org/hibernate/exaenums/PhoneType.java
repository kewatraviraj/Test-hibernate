/**
 * 
 */
package org.hibernate.exaenums;

/**
 * @author Dell
 *
 */
public enum PhoneType {
	    LAND_LINE,
	    MOBILE;
}
