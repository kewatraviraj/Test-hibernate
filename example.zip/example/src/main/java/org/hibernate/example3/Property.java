/**
 * 
 */
package org.hibernate.example3;

/**
 * @author Dell
 *
 */
public interface Property<T> {

    String getName();

    T getValue();
}
