/**
 * 
 */
package org.hibernate.example3;

/**
 * @author Dell
 *
 */
public interface Coordinates {
	double x();
	double y();
}